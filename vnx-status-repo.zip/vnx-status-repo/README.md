# VNX Store — Status Checker

Repo ini isinya "mesin status" buat website VNX STORE.

- `check-status.mjs` — script yang cek apakah Instagram/TikTok/Facebook/dst bisa diakses.
- `.github/workflows/status.yml` — jadwal GitHub Actions, jalan tiap 5 menit, nulis ulang `status.json`.
- `status.json` — hasil pengecekan terakhir. File ini yang dibaca website lewat GitHub Pages.

## Cara aktifin di website
1. Aktifkan GitHub Pages di repo ini (Settings → Pages → Branch: `main` / `master`, folder `/root`).
2. Salin URL Pages-nya, formatnya: `https://USERNAME.github.io/NAMA-REPO/status.json`
3. Paste ke `js/config.js` di project website → `statusFeedUrl`.
4. Upload ulang ZIP website ke Wibusoft.

## Opsional: cek status pembayaran & notifikasi WA
Di GitHub repo ini: Settings → Secrets and variables → Actions → New repository secret.
- `PAYMENT_STATUS_URL` — URL endpoint yang dianggap "tanda payment gateway hidup".
- `NOTIF_WA_STATUS_URL` — URL endpoint pengirim notifikasi WA.

Kalau secret ini kosong, kedua item itu otomatis berstatus "unknown" (bukan dianggap gangguan).
